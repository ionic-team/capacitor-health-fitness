package com.outsystems.plugins.healthfitness.background.database;

import android.database.Cursor;
import androidx.annotation.NonNull;
import androidx.room.EntityDeletionOrUpdateAdapter;
import androidx.room.EntityInsertionAdapter;
import androidx.room.RoomDatabase;
import androidx.room.RoomSQLiteQuery;
import androidx.room.util.CursorUtil;
import androidx.room.util.DBUtil;
import androidx.sqlite.db.SupportSQLiteStatement;
import java.lang.Class;
import java.lang.Integer;
import java.lang.Long;
import java.lang.Override;
import java.lang.String;
import java.lang.SuppressWarnings;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

@SuppressWarnings({"unchecked", "deprecation"})
public final class BackgroundJobDao_Impl implements BackgroundJobDao {
  private final RoomDatabase __db;

  private final EntityInsertionAdapter<BackgroundJob> __insertionAdapterOfBackgroundJob;

  private final EntityDeletionOrUpdateAdapter<BackgroundJob> __deletionAdapterOfBackgroundJob;

  private final EntityDeletionOrUpdateAdapter<BackgroundJob> __updateAdapterOfBackgroundJob;

  public BackgroundJobDao_Impl(@NonNull final RoomDatabase __db) {
    this.__db = __db;
    this.__insertionAdapterOfBackgroundJob = new EntityInsertionAdapter<BackgroundJob>(__db) {
      @Override
      @NonNull
      protected String createQuery() {
        return "INSERT OR ABORT INTO `backgroundJob_2` (`id`,`variable`,`comparison`,`value`,`time_unit`,`time_unit_grouping`,`notification_id`,`notification_frequency`,`notification_frequency_grouping`,`next_notification_timestamp`,`isActive`) VALUES (?,?,?,?,?,?,?,?,?,?,?)";
      }

      @Override
      protected void bind(@NonNull final SupportSQLiteStatement statement,
          @NonNull final BackgroundJob entity) {
        if (entity.getId() == null) {
          statement.bindNull(1);
        } else {
          statement.bindString(1, entity.getId());
        }
        if (entity.getVariable() == null) {
          statement.bindNull(2);
        } else {
          statement.bindString(2, entity.getVariable());
        }
        if (entity.getComparison() == null) {
          statement.bindNull(3);
        } else {
          statement.bindString(3, entity.getComparison());
        }
        statement.bindDouble(4, entity.getValue());
        if (entity.getTimeUnit() == null) {
          statement.bindNull(5);
        } else {
          statement.bindString(5, entity.getTimeUnit());
        }
        if (entity.getTimeUnitGrouping() == null) {
          statement.bindNull(6);
        } else {
          statement.bindLong(6, entity.getTimeUnitGrouping());
        }
        if (entity.getNotificationId() == null) {
          statement.bindNull(7);
        } else {
          statement.bindLong(7, entity.getNotificationId());
        }
        if (entity.getNotificationFrequency() == null) {
          statement.bindNull(8);
        } else {
          statement.bindString(8, entity.getNotificationFrequency());
        }
        statement.bindLong(9, entity.getNotificationFrequencyGrouping());
        statement.bindLong(10, entity.getNextNotificationTimestamp());
        final int _tmp = entity.isActive() ? 1 : 0;
        statement.bindLong(11, _tmp);
      }
    };
    this.__deletionAdapterOfBackgroundJob = new EntityDeletionOrUpdateAdapter<BackgroundJob>(__db) {
      @Override
      @NonNull
      protected String createQuery() {
        return "DELETE FROM `backgroundJob_2` WHERE `id` = ?";
      }

      @Override
      protected void bind(@NonNull final SupportSQLiteStatement statement,
          @NonNull final BackgroundJob entity) {
        if (entity.getId() == null) {
          statement.bindNull(1);
        } else {
          statement.bindString(1, entity.getId());
        }
      }
    };
    this.__updateAdapterOfBackgroundJob = new EntityDeletionOrUpdateAdapter<BackgroundJob>(__db) {
      @Override
      @NonNull
      protected String createQuery() {
        return "UPDATE OR ABORT `backgroundJob_2` SET `id` = ?,`variable` = ?,`comparison` = ?,`value` = ?,`time_unit` = ?,`time_unit_grouping` = ?,`notification_id` = ?,`notification_frequency` = ?,`notification_frequency_grouping` = ?,`next_notification_timestamp` = ?,`isActive` = ? WHERE `id` = ?";
      }

      @Override
      protected void bind(@NonNull final SupportSQLiteStatement statement,
          @NonNull final BackgroundJob entity) {
        if (entity.getId() == null) {
          statement.bindNull(1);
        } else {
          statement.bindString(1, entity.getId());
        }
        if (entity.getVariable() == null) {
          statement.bindNull(2);
        } else {
          statement.bindString(2, entity.getVariable());
        }
        if (entity.getComparison() == null) {
          statement.bindNull(3);
        } else {
          statement.bindString(3, entity.getComparison());
        }
        statement.bindDouble(4, entity.getValue());
        if (entity.getTimeUnit() == null) {
          statement.bindNull(5);
        } else {
          statement.bindString(5, entity.getTimeUnit());
        }
        if (entity.getTimeUnitGrouping() == null) {
          statement.bindNull(6);
        } else {
          statement.bindLong(6, entity.getTimeUnitGrouping());
        }
        if (entity.getNotificationId() == null) {
          statement.bindNull(7);
        } else {
          statement.bindLong(7, entity.getNotificationId());
        }
        if (entity.getNotificationFrequency() == null) {
          statement.bindNull(8);
        } else {
          statement.bindString(8, entity.getNotificationFrequency());
        }
        statement.bindLong(9, entity.getNotificationFrequencyGrouping());
        statement.bindLong(10, entity.getNextNotificationTimestamp());
        final int _tmp = entity.isActive() ? 1 : 0;
        statement.bindLong(11, _tmp);
        if (entity.getId() == null) {
          statement.bindNull(12);
        } else {
          statement.bindString(12, entity.getId());
        }
      }
    };
  }

  @Override
  public long insert(final BackgroundJob backgroundJob) {
    __db.assertNotSuspendingTransaction();
    __db.beginTransaction();
    try {
      final long _result = __insertionAdapterOfBackgroundJob.insertAndReturnId(backgroundJob);
      __db.setTransactionSuccessful();
      return _result;
    } finally {
      __db.endTransaction();
    }
  }

  @Override
  public void delete(final BackgroundJob backgroundJob) {
    __db.assertNotSuspendingTransaction();
    __db.beginTransaction();
    try {
      __deletionAdapterOfBackgroundJob.handle(backgroundJob);
      __db.setTransactionSuccessful();
    } finally {
      __db.endTransaction();
    }
  }

  @Override
  public void update(final BackgroundJob backgroundJob) {
    __db.assertNotSuspendingTransaction();
    __db.beginTransaction();
    try {
      __updateAdapterOfBackgroundJob.handle(backgroundJob);
      __db.setTransactionSuccessful();
    } finally {
      __db.endTransaction();
    }
  }

  @Override
  public List<BackgroundJob> getAll() {
    final String _sql = "SELECT * FROM backgroundJob_2";
    final RoomSQLiteQuery _statement = RoomSQLiteQuery.acquire(_sql, 0);
    __db.assertNotSuspendingTransaction();
    final Cursor _cursor = DBUtil.query(__db, _statement, false, null);
    try {
      final int _cursorIndexOfId = CursorUtil.getColumnIndexOrThrow(_cursor, "id");
      final int _cursorIndexOfVariable = CursorUtil.getColumnIndexOrThrow(_cursor, "variable");
      final int _cursorIndexOfComparison = CursorUtil.getColumnIndexOrThrow(_cursor, "comparison");
      final int _cursorIndexOfValue = CursorUtil.getColumnIndexOrThrow(_cursor, "value");
      final int _cursorIndexOfTimeUnit = CursorUtil.getColumnIndexOrThrow(_cursor, "time_unit");
      final int _cursorIndexOfTimeUnitGrouping = CursorUtil.getColumnIndexOrThrow(_cursor, "time_unit_grouping");
      final int _cursorIndexOfNotificationId = CursorUtil.getColumnIndexOrThrow(_cursor, "notification_id");
      final int _cursorIndexOfNotificationFrequency = CursorUtil.getColumnIndexOrThrow(_cursor, "notification_frequency");
      final int _cursorIndexOfNotificationFrequencyGrouping = CursorUtil.getColumnIndexOrThrow(_cursor, "notification_frequency_grouping");
      final int _cursorIndexOfNextNotificationTimestamp = CursorUtil.getColumnIndexOrThrow(_cursor, "next_notification_timestamp");
      final int _cursorIndexOfIsActive = CursorUtil.getColumnIndexOrThrow(_cursor, "isActive");
      final List<BackgroundJob> _result = new ArrayList<BackgroundJob>(_cursor.getCount());
      while (_cursor.moveToNext()) {
        final BackgroundJob _item;
        _item = new BackgroundJob();
        final String _tmpId;
        if (_cursor.isNull(_cursorIndexOfId)) {
          _tmpId = null;
        } else {
          _tmpId = _cursor.getString(_cursorIndexOfId);
        }
        _item.setId(_tmpId);
        final String _tmpVariable;
        if (_cursor.isNull(_cursorIndexOfVariable)) {
          _tmpVariable = null;
        } else {
          _tmpVariable = _cursor.getString(_cursorIndexOfVariable);
        }
        _item.setVariable(_tmpVariable);
        final String _tmpComparison;
        if (_cursor.isNull(_cursorIndexOfComparison)) {
          _tmpComparison = null;
        } else {
          _tmpComparison = _cursor.getString(_cursorIndexOfComparison);
        }
        _item.setComparison(_tmpComparison);
        final float _tmpValue;
        _tmpValue = _cursor.getFloat(_cursorIndexOfValue);
        _item.setValue(_tmpValue);
        final String _tmpTimeUnit;
        if (_cursor.isNull(_cursorIndexOfTimeUnit)) {
          _tmpTimeUnit = null;
        } else {
          _tmpTimeUnit = _cursor.getString(_cursorIndexOfTimeUnit);
        }
        _item.setTimeUnit(_tmpTimeUnit);
        final Integer _tmpTimeUnitGrouping;
        if (_cursor.isNull(_cursorIndexOfTimeUnitGrouping)) {
          _tmpTimeUnitGrouping = null;
        } else {
          _tmpTimeUnitGrouping = _cursor.getInt(_cursorIndexOfTimeUnitGrouping);
        }
        _item.setTimeUnitGrouping(_tmpTimeUnitGrouping);
        final Long _tmpNotificationId;
        if (_cursor.isNull(_cursorIndexOfNotificationId)) {
          _tmpNotificationId = null;
        } else {
          _tmpNotificationId = _cursor.getLong(_cursorIndexOfNotificationId);
        }
        _item.setNotificationId(_tmpNotificationId);
        final String _tmpNotificationFrequency;
        if (_cursor.isNull(_cursorIndexOfNotificationFrequency)) {
          _tmpNotificationFrequency = null;
        } else {
          _tmpNotificationFrequency = _cursor.getString(_cursorIndexOfNotificationFrequency);
        }
        _item.setNotificationFrequency(_tmpNotificationFrequency);
        final int _tmpNotificationFrequencyGrouping;
        _tmpNotificationFrequencyGrouping = _cursor.getInt(_cursorIndexOfNotificationFrequencyGrouping);
        _item.setNotificationFrequencyGrouping(_tmpNotificationFrequencyGrouping);
        final long _tmpNextNotificationTimestamp;
        _tmpNextNotificationTimestamp = _cursor.getLong(_cursorIndexOfNextNotificationTimestamp);
        _item.setNextNotificationTimestamp(_tmpNextNotificationTimestamp);
        final boolean _tmpIsActive;
        final int _tmp;
        _tmp = _cursor.getInt(_cursorIndexOfIsActive);
        _tmpIsActive = _tmp != 0;
        _item.setActive(_tmpIsActive);
        _result.add(_item);
      }
      return _result;
    } finally {
      _cursor.close();
      _statement.release();
    }
  }

  @Override
  public int getBackgroundJobCountForVariable(final String name) {
    final String _sql = "SELECT COUNT(*) FROM backgroundJob_2 WHERE variable = ?";
    final RoomSQLiteQuery _statement = RoomSQLiteQuery.acquire(_sql, 1);
    int _argIndex = 1;
    if (name == null) {
      _statement.bindNull(_argIndex);
    } else {
      _statement.bindString(_argIndex, name);
    }
    __db.assertNotSuspendingTransaction();
    final Cursor _cursor = DBUtil.query(__db, _statement, false, null);
    try {
      final int _result;
      if (_cursor.moveToFirst()) {
        _result = _cursor.getInt(0);
      } else {
        _result = 0;
      }
      return _result;
    } finally {
      _cursor.close();
      _statement.release();
    }
  }

  @Override
  public BackgroundJob findById(final String id) {
    final String _sql = "SELECT * FROM backgroundJob_2 WHERE id = ?";
    final RoomSQLiteQuery _statement = RoomSQLiteQuery.acquire(_sql, 1);
    int _argIndex = 1;
    if (id == null) {
      _statement.bindNull(_argIndex);
    } else {
      _statement.bindString(_argIndex, id);
    }
    __db.assertNotSuspendingTransaction();
    final Cursor _cursor = DBUtil.query(__db, _statement, false, null);
    try {
      final int _cursorIndexOfId = CursorUtil.getColumnIndexOrThrow(_cursor, "id");
      final int _cursorIndexOfVariable = CursorUtil.getColumnIndexOrThrow(_cursor, "variable");
      final int _cursorIndexOfComparison = CursorUtil.getColumnIndexOrThrow(_cursor, "comparison");
      final int _cursorIndexOfValue = CursorUtil.getColumnIndexOrThrow(_cursor, "value");
      final int _cursorIndexOfTimeUnit = CursorUtil.getColumnIndexOrThrow(_cursor, "time_unit");
      final int _cursorIndexOfTimeUnitGrouping = CursorUtil.getColumnIndexOrThrow(_cursor, "time_unit_grouping");
      final int _cursorIndexOfNotificationId = CursorUtil.getColumnIndexOrThrow(_cursor, "notification_id");
      final int _cursorIndexOfNotificationFrequency = CursorUtil.getColumnIndexOrThrow(_cursor, "notification_frequency");
      final int _cursorIndexOfNotificationFrequencyGrouping = CursorUtil.getColumnIndexOrThrow(_cursor, "notification_frequency_grouping");
      final int _cursorIndexOfNextNotificationTimestamp = CursorUtil.getColumnIndexOrThrow(_cursor, "next_notification_timestamp");
      final int _cursorIndexOfIsActive = CursorUtil.getColumnIndexOrThrow(_cursor, "isActive");
      final BackgroundJob _result;
      if (_cursor.moveToFirst()) {
        _result = new BackgroundJob();
        final String _tmpId;
        if (_cursor.isNull(_cursorIndexOfId)) {
          _tmpId = null;
        } else {
          _tmpId = _cursor.getString(_cursorIndexOfId);
        }
        _result.setId(_tmpId);
        final String _tmpVariable;
        if (_cursor.isNull(_cursorIndexOfVariable)) {
          _tmpVariable = null;
        } else {
          _tmpVariable = _cursor.getString(_cursorIndexOfVariable);
        }
        _result.setVariable(_tmpVariable);
        final String _tmpComparison;
        if (_cursor.isNull(_cursorIndexOfComparison)) {
          _tmpComparison = null;
        } else {
          _tmpComparison = _cursor.getString(_cursorIndexOfComparison);
        }
        _result.setComparison(_tmpComparison);
        final float _tmpValue;
        _tmpValue = _cursor.getFloat(_cursorIndexOfValue);
        _result.setValue(_tmpValue);
        final String _tmpTimeUnit;
        if (_cursor.isNull(_cursorIndexOfTimeUnit)) {
          _tmpTimeUnit = null;
        } else {
          _tmpTimeUnit = _cursor.getString(_cursorIndexOfTimeUnit);
        }
        _result.setTimeUnit(_tmpTimeUnit);
        final Integer _tmpTimeUnitGrouping;
        if (_cursor.isNull(_cursorIndexOfTimeUnitGrouping)) {
          _tmpTimeUnitGrouping = null;
        } else {
          _tmpTimeUnitGrouping = _cursor.getInt(_cursorIndexOfTimeUnitGrouping);
        }
        _result.setTimeUnitGrouping(_tmpTimeUnitGrouping);
        final Long _tmpNotificationId;
        if (_cursor.isNull(_cursorIndexOfNotificationId)) {
          _tmpNotificationId = null;
        } else {
          _tmpNotificationId = _cursor.getLong(_cursorIndexOfNotificationId);
        }
        _result.setNotificationId(_tmpNotificationId);
        final String _tmpNotificationFrequency;
        if (_cursor.isNull(_cursorIndexOfNotificationFrequency)) {
          _tmpNotificationFrequency = null;
        } else {
          _tmpNotificationFrequency = _cursor.getString(_cursorIndexOfNotificationFrequency);
        }
        _result.setNotificationFrequency(_tmpNotificationFrequency);
        final int _tmpNotificationFrequencyGrouping;
        _tmpNotificationFrequencyGrouping = _cursor.getInt(_cursorIndexOfNotificationFrequencyGrouping);
        _result.setNotificationFrequencyGrouping(_tmpNotificationFrequencyGrouping);
        final long _tmpNextNotificationTimestamp;
        _tmpNextNotificationTimestamp = _cursor.getLong(_cursorIndexOfNextNotificationTimestamp);
        _result.setNextNotificationTimestamp(_tmpNextNotificationTimestamp);
        final boolean _tmpIsActive;
        final int _tmp;
        _tmp = _cursor.getInt(_cursorIndexOfIsActive);
        _tmpIsActive = _tmp != 0;
        _result.setActive(_tmpIsActive);
      } else {
        _result = null;
      }
      return _result;
    } finally {
      _cursor.close();
      _statement.release();
    }
  }

  @Override
  public List<BackgroundJob> findByVariableName(final String name) {
    final String _sql = "SELECT * FROM backgroundJob_2 WHERE variable = ?";
    final RoomSQLiteQuery _statement = RoomSQLiteQuery.acquire(_sql, 1);
    int _argIndex = 1;
    if (name == null) {
      _statement.bindNull(_argIndex);
    } else {
      _statement.bindString(_argIndex, name);
    }
    __db.assertNotSuspendingTransaction();
    final Cursor _cursor = DBUtil.query(__db, _statement, false, null);
    try {
      final int _cursorIndexOfId = CursorUtil.getColumnIndexOrThrow(_cursor, "id");
      final int _cursorIndexOfVariable = CursorUtil.getColumnIndexOrThrow(_cursor, "variable");
      final int _cursorIndexOfComparison = CursorUtil.getColumnIndexOrThrow(_cursor, "comparison");
      final int _cursorIndexOfValue = CursorUtil.getColumnIndexOrThrow(_cursor, "value");
      final int _cursorIndexOfTimeUnit = CursorUtil.getColumnIndexOrThrow(_cursor, "time_unit");
      final int _cursorIndexOfTimeUnitGrouping = CursorUtil.getColumnIndexOrThrow(_cursor, "time_unit_grouping");
      final int _cursorIndexOfNotificationId = CursorUtil.getColumnIndexOrThrow(_cursor, "notification_id");
      final int _cursorIndexOfNotificationFrequency = CursorUtil.getColumnIndexOrThrow(_cursor, "notification_frequency");
      final int _cursorIndexOfNotificationFrequencyGrouping = CursorUtil.getColumnIndexOrThrow(_cursor, "notification_frequency_grouping");
      final int _cursorIndexOfNextNotificationTimestamp = CursorUtil.getColumnIndexOrThrow(_cursor, "next_notification_timestamp");
      final int _cursorIndexOfIsActive = CursorUtil.getColumnIndexOrThrow(_cursor, "isActive");
      final List<BackgroundJob> _result = new ArrayList<BackgroundJob>(_cursor.getCount());
      while (_cursor.moveToNext()) {
        final BackgroundJob _item;
        _item = new BackgroundJob();
        final String _tmpId;
        if (_cursor.isNull(_cursorIndexOfId)) {
          _tmpId = null;
        } else {
          _tmpId = _cursor.getString(_cursorIndexOfId);
        }
        _item.setId(_tmpId);
        final String _tmpVariable;
        if (_cursor.isNull(_cursorIndexOfVariable)) {
          _tmpVariable = null;
        } else {
          _tmpVariable = _cursor.getString(_cursorIndexOfVariable);
        }
        _item.setVariable(_tmpVariable);
        final String _tmpComparison;
        if (_cursor.isNull(_cursorIndexOfComparison)) {
          _tmpComparison = null;
        } else {
          _tmpComparison = _cursor.getString(_cursorIndexOfComparison);
        }
        _item.setComparison(_tmpComparison);
        final float _tmpValue;
        _tmpValue = _cursor.getFloat(_cursorIndexOfValue);
        _item.setValue(_tmpValue);
        final String _tmpTimeUnit;
        if (_cursor.isNull(_cursorIndexOfTimeUnit)) {
          _tmpTimeUnit = null;
        } else {
          _tmpTimeUnit = _cursor.getString(_cursorIndexOfTimeUnit);
        }
        _item.setTimeUnit(_tmpTimeUnit);
        final Integer _tmpTimeUnitGrouping;
        if (_cursor.isNull(_cursorIndexOfTimeUnitGrouping)) {
          _tmpTimeUnitGrouping = null;
        } else {
          _tmpTimeUnitGrouping = _cursor.getInt(_cursorIndexOfTimeUnitGrouping);
        }
        _item.setTimeUnitGrouping(_tmpTimeUnitGrouping);
        final Long _tmpNotificationId;
        if (_cursor.isNull(_cursorIndexOfNotificationId)) {
          _tmpNotificationId = null;
        } else {
          _tmpNotificationId = _cursor.getLong(_cursorIndexOfNotificationId);
        }
        _item.setNotificationId(_tmpNotificationId);
        final String _tmpNotificationFrequency;
        if (_cursor.isNull(_cursorIndexOfNotificationFrequency)) {
          _tmpNotificationFrequency = null;
        } else {
          _tmpNotificationFrequency = _cursor.getString(_cursorIndexOfNotificationFrequency);
        }
        _item.setNotificationFrequency(_tmpNotificationFrequency);
        final int _tmpNotificationFrequencyGrouping;
        _tmpNotificationFrequencyGrouping = _cursor.getInt(_cursorIndexOfNotificationFrequencyGrouping);
        _item.setNotificationFrequencyGrouping(_tmpNotificationFrequencyGrouping);
        final long _tmpNextNotificationTimestamp;
        _tmpNextNotificationTimestamp = _cursor.getLong(_cursorIndexOfNextNotificationTimestamp);
        _item.setNextNotificationTimestamp(_tmpNextNotificationTimestamp);
        final boolean _tmpIsActive;
        final int _tmp;
        _tmp = _cursor.getInt(_cursorIndexOfIsActive);
        _tmpIsActive = _tmp != 0;
        _item.setActive(_tmpIsActive);
        _result.add(_item);
      }
      return _result;
    } finally {
      _cursor.close();
      _statement.release();
    }
  }

  @NonNull
  public static List<Class<?>> getRequiredConverters() {
    return Collections.emptyList();
  }
}
