package com.outsystems.plugins.healthfitness.background.database;

import androidx.annotation.NonNull;
import androidx.room.DatabaseConfiguration;
import androidx.room.InvalidationTracker;
import androidx.room.RoomDatabase;
import androidx.room.RoomOpenHelper;
import androidx.room.migration.AutoMigrationSpec;
import androidx.room.migration.Migration;
import androidx.room.util.DBUtil;
import androidx.room.util.TableInfo;
import androidx.sqlite.db.SupportSQLiteDatabase;
import androidx.sqlite.db.SupportSQLiteOpenHelper;
import java.lang.Class;
import java.lang.Override;
import java.lang.String;
import java.lang.SuppressWarnings;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

@SuppressWarnings({"unchecked", "deprecation"})
public final class AppDatabase_Impl extends AppDatabase {
  private volatile BackgroundJobDao _backgroundJobDao;

  private volatile NotificationDao _notificationDao;

  @Override
  @NonNull
  protected SupportSQLiteOpenHelper createOpenHelper(@NonNull final DatabaseConfiguration config) {
    final SupportSQLiteOpenHelper.Callback _openCallback = new RoomOpenHelper(config, new RoomOpenHelper.Delegate(2) {
      @Override
      public void createAllTables(@NonNull final SupportSQLiteDatabase db) {
        db.execSQL("CREATE TABLE IF NOT EXISTS `backgroundJob_2` (`id` TEXT NOT NULL, `variable` TEXT NOT NULL, `comparison` TEXT NOT NULL, `value` REAL NOT NULL, `time_unit` TEXT, `time_unit_grouping` INTEGER, `notification_id` INTEGER, `notification_frequency` TEXT NOT NULL, `notification_frequency_grouping` INTEGER NOT NULL, `next_notification_timestamp` INTEGER NOT NULL, `isActive` INTEGER NOT NULL, PRIMARY KEY(`id`), FOREIGN KEY(`notification_id`) REFERENCES `Notification`(`id`) ON UPDATE NO ACTION ON DELETE CASCADE )");
        db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS `unique_bg_job` ON `backgroundJob_2` (`variable`, `comparison`, `value`)");
        db.execSQL("CREATE TABLE IF NOT EXISTS `Notification` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `notification_id` INTEGER NOT NULL, `title` TEXT NOT NULL, `body` TEXT NOT NULL)");
        db.execSQL("CREATE TABLE IF NOT EXISTS room_master_table (id INTEGER PRIMARY KEY,identity_hash TEXT)");
        db.execSQL("INSERT OR REPLACE INTO room_master_table (id,identity_hash) VALUES(42, '280f8ebf42453ff76678c5e2289e0cf6')");
      }

      @Override
      public void dropAllTables(@NonNull final SupportSQLiteDatabase db) {
        db.execSQL("DROP TABLE IF EXISTS `backgroundJob_2`");
        db.execSQL("DROP TABLE IF EXISTS `Notification`");
        final List<? extends RoomDatabase.Callback> _callbacks = mCallbacks;
        if (_callbacks != null) {
          for (RoomDatabase.Callback _callback : _callbacks) {
            _callback.onDestructiveMigration(db);
          }
        }
      }

      @Override
      public void onCreate(@NonNull final SupportSQLiteDatabase db) {
        final List<? extends RoomDatabase.Callback> _callbacks = mCallbacks;
        if (_callbacks != null) {
          for (RoomDatabase.Callback _callback : _callbacks) {
            _callback.onCreate(db);
          }
        }
      }

      @Override
      public void onOpen(@NonNull final SupportSQLiteDatabase db) {
        mDatabase = db;
        db.execSQL("PRAGMA foreign_keys = ON");
        internalInitInvalidationTracker(db);
        final List<? extends RoomDatabase.Callback> _callbacks = mCallbacks;
        if (_callbacks != null) {
          for (RoomDatabase.Callback _callback : _callbacks) {
            _callback.onOpen(db);
          }
        }
      }

      @Override
      public void onPreMigrate(@NonNull final SupportSQLiteDatabase db) {
        DBUtil.dropFtsSyncTriggers(db);
      }

      @Override
      public void onPostMigrate(@NonNull final SupportSQLiteDatabase db) {
      }

      @Override
      @NonNull
      public RoomOpenHelper.ValidationResult onValidateSchema(
          @NonNull final SupportSQLiteDatabase db) {
        final HashMap<String, TableInfo.Column> _columnsBackgroundJob2 = new HashMap<String, TableInfo.Column>(11);
        _columnsBackgroundJob2.put("id", new TableInfo.Column("id", "TEXT", true, 1, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsBackgroundJob2.put("variable", new TableInfo.Column("variable", "TEXT", true, 0, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsBackgroundJob2.put("comparison", new TableInfo.Column("comparison", "TEXT", true, 0, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsBackgroundJob2.put("value", new TableInfo.Column("value", "REAL", true, 0, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsBackgroundJob2.put("time_unit", new TableInfo.Column("time_unit", "TEXT", false, 0, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsBackgroundJob2.put("time_unit_grouping", new TableInfo.Column("time_unit_grouping", "INTEGER", false, 0, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsBackgroundJob2.put("notification_id", new TableInfo.Column("notification_id", "INTEGER", false, 0, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsBackgroundJob2.put("notification_frequency", new TableInfo.Column("notification_frequency", "TEXT", true, 0, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsBackgroundJob2.put("notification_frequency_grouping", new TableInfo.Column("notification_frequency_grouping", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsBackgroundJob2.put("next_notification_timestamp", new TableInfo.Column("next_notification_timestamp", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsBackgroundJob2.put("isActive", new TableInfo.Column("isActive", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY));
        final HashSet<TableInfo.ForeignKey> _foreignKeysBackgroundJob2 = new HashSet<TableInfo.ForeignKey>(1);
        _foreignKeysBackgroundJob2.add(new TableInfo.ForeignKey("Notification", "CASCADE", "NO ACTION", Arrays.asList("notification_id"), Arrays.asList("id")));
        final HashSet<TableInfo.Index> _indicesBackgroundJob2 = new HashSet<TableInfo.Index>(1);
        _indicesBackgroundJob2.add(new TableInfo.Index("unique_bg_job", true, Arrays.asList("variable", "comparison", "value"), Arrays.asList("ASC", "ASC", "ASC")));
        final TableInfo _infoBackgroundJob2 = new TableInfo("backgroundJob_2", _columnsBackgroundJob2, _foreignKeysBackgroundJob2, _indicesBackgroundJob2);
        final TableInfo _existingBackgroundJob2 = TableInfo.read(db, "backgroundJob_2");
        if (!_infoBackgroundJob2.equals(_existingBackgroundJob2)) {
          return new RoomOpenHelper.ValidationResult(false, "backgroundJob_2(com.outsystems.plugins.healthfitness.background.database.BackgroundJob).\n"
                  + " Expected:\n" + _infoBackgroundJob2 + "\n"
                  + " Found:\n" + _existingBackgroundJob2);
        }
        final HashMap<String, TableInfo.Column> _columnsNotification = new HashMap<String, TableInfo.Column>(4);
        _columnsNotification.put("id", new TableInfo.Column("id", "INTEGER", true, 1, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsNotification.put("notification_id", new TableInfo.Column("notification_id", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsNotification.put("title", new TableInfo.Column("title", "TEXT", true, 0, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsNotification.put("body", new TableInfo.Column("body", "TEXT", true, 0, null, TableInfo.CREATED_FROM_ENTITY));
        final HashSet<TableInfo.ForeignKey> _foreignKeysNotification = new HashSet<TableInfo.ForeignKey>(0);
        final HashSet<TableInfo.Index> _indicesNotification = new HashSet<TableInfo.Index>(0);
        final TableInfo _infoNotification = new TableInfo("Notification", _columnsNotification, _foreignKeysNotification, _indicesNotification);
        final TableInfo _existingNotification = TableInfo.read(db, "Notification");
        if (!_infoNotification.equals(_existingNotification)) {
          return new RoomOpenHelper.ValidationResult(false, "Notification(com.outsystems.plugins.healthfitness.background.database.Notification).\n"
                  + " Expected:\n" + _infoNotification + "\n"
                  + " Found:\n" + _existingNotification);
        }
        return new RoomOpenHelper.ValidationResult(true, null);
      }
    }, "280f8ebf42453ff76678c5e2289e0cf6", "91eaacadfe32878c02e024acccfefefc");
    final SupportSQLiteOpenHelper.Configuration _sqliteConfig = SupportSQLiteOpenHelper.Configuration.builder(config.context).name(config.name).callback(_openCallback).build();
    final SupportSQLiteOpenHelper _helper = config.sqliteOpenHelperFactory.create(_sqliteConfig);
    return _helper;
  }

  @Override
  @NonNull
  protected InvalidationTracker createInvalidationTracker() {
    final HashMap<String, String> _shadowTablesMap = new HashMap<String, String>(0);
    final HashMap<String, Set<String>> _viewTables = new HashMap<String, Set<String>>(0);
    return new InvalidationTracker(this, _shadowTablesMap, _viewTables, "backgroundJob_2","Notification");
  }

  @Override
  public void clearAllTables() {
    super.assertNotMainThread();
    final SupportSQLiteDatabase _db = super.getOpenHelper().getWritableDatabase();
    final boolean _supportsDeferForeignKeys = android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.LOLLIPOP;
    try {
      if (!_supportsDeferForeignKeys) {
        _db.execSQL("PRAGMA foreign_keys = FALSE");
      }
      super.beginTransaction();
      if (_supportsDeferForeignKeys) {
        _db.execSQL("PRAGMA defer_foreign_keys = TRUE");
      }
      _db.execSQL("DELETE FROM `backgroundJob_2`");
      _db.execSQL("DELETE FROM `Notification`");
      super.setTransactionSuccessful();
    } finally {
      super.endTransaction();
      if (!_supportsDeferForeignKeys) {
        _db.execSQL("PRAGMA foreign_keys = TRUE");
      }
      _db.query("PRAGMA wal_checkpoint(FULL)").close();
      if (!_db.inTransaction()) {
        _db.execSQL("VACUUM");
      }
    }
  }

  @Override
  @NonNull
  protected Map<Class<?>, List<Class<?>>> getRequiredTypeConverters() {
    final HashMap<Class<?>, List<Class<?>>> _typeConvertersMap = new HashMap<Class<?>, List<Class<?>>>();
    _typeConvertersMap.put(BackgroundJobDao.class, BackgroundJobDao_Impl.getRequiredConverters());
    _typeConvertersMap.put(NotificationDao.class, NotificationDao_Impl.getRequiredConverters());
    return _typeConvertersMap;
  }

  @Override
  @NonNull
  public Set<Class<? extends AutoMigrationSpec>> getRequiredAutoMigrationSpecs() {
    final HashSet<Class<? extends AutoMigrationSpec>> _autoMigrationSpecsSet = new HashSet<Class<? extends AutoMigrationSpec>>();
    return _autoMigrationSpecsSet;
  }

  @Override
  @NonNull
  public List<Migration> getAutoMigrations(
      @NonNull final Map<Class<? extends AutoMigrationSpec>, AutoMigrationSpec> autoMigrationSpecs) {
    final List<Migration> _autoMigrations = new ArrayList<Migration>();
    return _autoMigrations;
  }

  @Override
  public BackgroundJobDao backgroundJobDao() {
    if (_backgroundJobDao != null) {
      return _backgroundJobDao;
    } else {
      synchronized(this) {
        if(_backgroundJobDao == null) {
          _backgroundJobDao = new BackgroundJobDao_Impl(this);
        }
        return _backgroundJobDao;
      }
    }
  }

  @Override
  public NotificationDao notificationDao() {
    if (_notificationDao != null) {
      return _notificationDao;
    } else {
      synchronized(this) {
        if(_notificationDao == null) {
          _notificationDao = new NotificationDao_Impl(this);
        }
        return _notificationDao;
      }
    }
  }
}
